# SkyNova Air + Duffel

This is the SkyNova Air frontend plus a Node/Express backend that keeps the Duffel token off the client and searches Duffel for places and flight offers.

## Setup
1. Install Node.js 18+.
2. Run `npm install`.
3. Set the environment variable `DUFFEL_ACCESS_TOKEN` to your Duffel token. Do not put the token in `public/index.html`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## Deployment
Deploy as a Node.js web service. Add `DUFFEL_ACCESS_TOKEN` in the host's environment/secrets settings. Do not publish `.env` or the token.
